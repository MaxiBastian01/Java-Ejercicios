package ejercicio2;

public enum ClasificacionNota {
APROBADO("Aprobado"),
REPROBADO("Reprobado"),
BUENO("Bueno"),
SOBRESALIENTE("Sobresaliente");
	
ClasificacionNota(String nombre) {
}

}
