package ejercicio2;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		 
		 System.out.println("Ingrese una calificación numérica (de 0 a 10):");
	     int calificacion = scanner.nextInt();
	     
	     if (calificacion <= 5) {
	            System.out.println(ClasificacionNota.REPROBADO);
	        } else if (calificacion >= 6 && calificacion < 7) {
	            System.out.println(ClasificacionNota.APROBADO);
	        } else if (calificacion >= 7 && calificacion <= 8) {
	            System.out.println((ClasificacionNota.BUENO));
	        } else if (calificacion > 8 && calificacion <= 10) {
	            System.out.println(ClasificacionNota.SOBRESALIENTE);
	        } else {
	            System.out.println("Por favor ingrese una calificación válida entre 0 y 10");
	        }
	     scanner.close();
	}

}