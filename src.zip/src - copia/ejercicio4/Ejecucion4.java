package ejercicio4;

import java.util.Arrays;

public class Ejecucion4 {
	public static void main(String[] args) {  
        Ejercicio4 array = new Ejercicio4();  
        
        System.out.println("Cantidad de números: " + array.contarNumeros());  
        System.out.println("Número mayor: " + array.encontrarMayor());  
        System.out.println("Promedio: " + array.calcularPromedio());  
        System.out.println("Ordenados de menor a mayor: " + Arrays.toString(array.ordenarMenor()));  
        System.out.println("Ordenados de mayor a menor: " + Arrays.toString(array.ordenarMayor()));  
    }  
}
