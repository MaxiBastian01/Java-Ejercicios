package ejercicio4;
import java.util.Arrays;

public class Ejercicio4 {  
	    private int[] numeros = {4, 2, 3, 8, 1};  
	    
	    public int contarNumeros() {  
	        return numeros.length;  
	    }  

	    public int encontrarMayor() {  
	        int mayor = numeros[0];  
	        for (int numM : numeros) {  
	            if (numM > mayor) {  
	                mayor = numM;  
	            }  
	        }  
	        return mayor;  
	    }  
	    
	    public double calcularPromedio() {  
	        int suma = 0;  
	        for (int num : numeros) {  
	            suma += num;  
	        }  
	        return (double) suma / contarNumeros();  
	    }  

	    public int[] ordenarMenor() {  
	        int[] numerosOrdenados = Arrays.copyOf(numeros, numeros.length);  
	        Arrays.sort(numerosOrdenados);  
	        return numerosOrdenados;  
	    }  
	    
	    public int[] ordenarMayor() {  
	        int[] numerosOrdenados = ordenarMenor();  
	        int[] numerosInversa = new int[numerosOrdenados.length];  
	        for (int i = 0; i < numerosOrdenados.length; i++) {  
	            numerosInversa[i] = numerosOrdenados[numerosOrdenados.length - 1 - i];  
	        }  
	        return numerosInversa;  
	    }  
	}  