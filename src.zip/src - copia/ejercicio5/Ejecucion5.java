package ejercicio5;

import java.util.Scanner;

public class Ejecucion5 {
	 public static void main(String[] args) {
	    	Scanner scanner = new Scanner(System.in);

	        System.out.print("Ingresa un número: ");
	        int numeroIngresado = scanner.nextInt();
	        
	        Ejercicio5 num = new Ejercicio5(numeroIngresado);

	        System.out.println("Número: " + num.getNumero());
	        System.out.println("Cuadrado: " + num.cuadrado());
	        System.out.println("Es par: " + num.Par());
	        System.out.println("Es impar: " + num.Impar());
	        System.out.println("Factorial: " + num.factorial());
	        System.out.println("Es primo: " + num.Primo());
	        
	        scanner.close();
	    }

}
