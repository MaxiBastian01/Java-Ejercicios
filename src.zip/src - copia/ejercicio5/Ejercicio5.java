package ejercicio5;



public class Ejercicio5 {
    private int numero;

    public Ejercicio5(int numero) {
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public long cuadrado() {
        return (long) numero * numero;
    }

    public boolean Par() {
        return numero % 2 == 0;
    }

    public boolean Impar() {
        return !Par();
    }

    public int factorial() {
        if (numero < 0) {
            throw new IllegalArgumentException("El número debe ser no negativo.");
        }
        int resultado = 1;
        for (int i = 1; i <= numero; i++) {
            resultado *= i;
        }
        return resultado;
    }

    public boolean Primo() {
        if (numero < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }

   
}

