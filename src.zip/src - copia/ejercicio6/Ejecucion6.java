package ejercicio6;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejecucion6 {
	  public static void main(String[] args) {
	        final String REGISTRAR = "S";
	        Scanner scanner = new Scanner(System.in);
	        ArrayList<Ejercicio6> empleados = new ArrayList<>();
	        String opcion;

	        do {
	            System.out.print("¿Desea registrar un empleado? Si=S, No=N: ");
	            opcion = scanner.nextLine();

	            if (opcion.equalsIgnoreCase(REGISTRAR)) {
	                System.out.print("Ingrese el nombre del empleado: ");
	                String nombre = scanner.nextLine();
	                System.out.print("Ingrese el sueldo del empleado: ");
	                double sueldo = scanner.nextDouble();
	                scanner.nextLine(); 
	                if (sueldo >= 0) {
	                    empleados.add(new Ejercicio6(nombre, sueldo));
	                } else {
	                    System.out.println("El sueldo no puede ser negativo. Intente nuevamente.");
	                }
	            }
	        } while (opcion.equalsIgnoreCase(REGISTRAR));
	        if (!empleados.isEmpty()) {
	            Ejercicio6 empleadoMaximo = empleados.get(0);
	            double sumaSueldos = 0;

	            for (Ejercicio6 empleado : empleados) {
	                sumaSueldos += empleado.getSueldo();
	                if (empleado.getSueldo() > empleadoMaximo.getSueldo()) {
	                    empleadoMaximo = empleado;
	                }
	            }

	            double sueldoPromedio = sumaSueldos / empleados.size();

	            System.out.println("El empleado con el sueldo más alto es: " + empleadoMaximo.getNombre() +
	                    " con un sueldo de: " + empleadoMaximo.getSueldo());
	            System.out.println("El sueldo promedio es: " + sueldoPromedio);
	        } else {
	            System.out.println("No se registraron empleados.");
	        }

	        scanner.close();
	    }

}
