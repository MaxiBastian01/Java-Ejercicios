package ejercicio6;

public class Ejercicio6 {

    private String nombre;
    private double sueldo;


    public Ejercicio6(String nombre, double sueldo) {
        this.nombre = nombre;
        this.sueldo = sueldo;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        if (sueldo >= 0) { 
        } else {
            System.out.println("El sueldo no puede ser negativo.");
        }
    }

}
